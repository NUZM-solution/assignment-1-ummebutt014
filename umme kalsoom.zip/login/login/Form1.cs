namespace login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Trim() == "" && textBox2.Text.Trim() == "")
            {
                MessageBox.Show("please Enter Username and Password");
            }
            else
            {
                if(textBox1.Text == "admin" && textBox2.Text == "admin")
                {
                    MessageBox.Show(" you are successfully login");
                }
                else
                {
                    MessageBox.Show(" Username and password is incorrect");
                }
            }
        }
    }
}
