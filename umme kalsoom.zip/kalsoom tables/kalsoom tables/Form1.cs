using System.Net.NetworkInformation;

namespace kalsoom_tables
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //get data from input fields (replace these with your actual input fields)
            string Id = this.textBox1.Text;
            string Name = this.textBox2.Text;
            string age = this.textBox3.Text;
            string address = this.textBox4.Text;
            //add a new row to the datagrid view 
            DataGridViewRow newRow = new DataGridViewRow();
            //create cells for each column in the dataGridview
            DataGridViewCell cell1 = new DataGridViewTextBoxCell();
            DataGridViewCell cell2 = new DataGridViewTextBoxCell();
            DataGridViewCell cell3 = new DataGridViewTextBoxCell();
            DataGridViewCell cell4 = new DataGridViewTextBoxCell();
            //set the cell values to the data from input fields
            cell1.Value = Id;
            cell2.Value = Name;
            cell3.Value = age;
            cell4.Value = address;
            //add cells to the new row
            newRow.Cells.Add(cell1);
            newRow.Cells.Add(cell2);
            newRow.Cells.Add(cell3);
            newRow.Cells.Add(cell4);

            dataGridView1.Rows.Add(newRow);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            textBox4.Text = "";

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    dataGridView1.Rows.Remove(row);
                }
            }
            else
            {
                MessageBox.Show("please select a row");

            }
        }
    }
}
